SAMIX CLOTHING STORE — FREE WEBSITE STARTER

FILES
- index.html: Complete responsive storefront with product cards, shopping bag, and WhatsApp order form.

IMPORTANT BEFORE LAUNCH
1. Open index.html in a text editor.
2. Find: const WHATSAPP_NUMBER = "91XXXXXXXXXX";
3. Replace it with your own WhatsApp number in digits only, including India country code 91.
   Example format: 919876543210
4. Update product names, sample prices, colours and descriptions in the PRODUCTS array.
5. Replace the illustrative CSS T-shirt mockups with real product photos before selling.
6. Add your real delivery, return, privacy and contact details. Do not publish fake claims.
7. Test on your phone and place a test order to your own number.

HOW ORDERING WORKS
- Customers add products to a bag.
- They enter name, phone, address and preferred payment.
- The site opens WhatsApp with the order details for you to confirm manually.
- It does NOT process payments, verify stock, calculate shipping, or automatically confirm orders.
- Do not collect card/bank passwords or OTPs.

FREE HOSTING WITH GITHUB PAGES
1. Sign in/create an account at https://github.com/
2. Create a new public repository named samix-store (or another name).
3. Upload index.html to the repository's root. You can also upload this README.
4. Open repository Settings -> Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Choose branch main and folder /(root), then Save.
7. Wait a few minutes; GitHub will show the published URL, usually:
   https://YOUR-USERNAME.github.io/samix-store/
8. Open that URL on your phone and test every product and the WhatsApp checkout.

COST
- GitHub Pages hosting: free for a public repository and static website.
- A custom domain is optional and usually costs extra.
- This is a static starter site, not a full e-commerce platform with admin dashboard or payment gateway.

AGE / BUSINESS NOTE
If you are under 18, involve a parent/guardian in account, payment, supplier, and business arrangements where required.
